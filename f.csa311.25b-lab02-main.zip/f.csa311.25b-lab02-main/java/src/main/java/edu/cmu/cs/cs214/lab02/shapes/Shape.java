package edu.cmu.cs.cs214.lab02.shapes;

public interface Shape {
    
}
